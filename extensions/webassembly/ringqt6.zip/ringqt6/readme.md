Ring For WebAssembly using Qt 6
===============================

Requirements:

* Qt 6.12 for WebAssembly (Using the Qt Online Installer)
* Emscripten (Use the version recommended by the Qt documentation for Qt 6.12)

See https://doc.qt.io/qt-6/wasm.html

Using Qt Creator Open the project : project/project.pro (Select the WebAssembly kit)

The Qt for WebAssembly kit doesn't contain some Qt modules, so the next classes are not included
(see project.pro and update_ring/update.bat):

	* Qt Multimedia (QMediaPlayer, QVideoWidget, QSoundEffect, audio/media recording, etc.)
	* Qt TextToSpeech
	* QProcess (disabled in Qt for WebAssembly), Qt Positioning, Qt 3D, Qt SerialPort, Qt Bluetooth, Qt WebEngine
	* Qt SQL (disabled), QUdpSocket and QSslSocket (disabled)

Update the project (Ring and RingQt6 source code)
=================================================

The RingQt6 files (project/ringqt) are generated from the folder : ring/extensions/ringqt6

	cd update_ring
	update.bat          (Update Ring and RingQt6)
	updateringonly.bat  (Update Ring only)

If the list of RingQt6 classes is changed, update the SOURCES/HEADERS sections in project.pro
(The file is based on ring/extensions/ringqt6/ring_qt6_nobluetooth.pro)

The Ring application (project/ringapp.ringo) is generated using

	ring ringapp.ring -go -norun

(Use the Qt 6 classes (ring_qt.ring) when generating the object file)
